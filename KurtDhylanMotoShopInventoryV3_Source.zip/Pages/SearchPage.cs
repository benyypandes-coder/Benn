using KurtDhylanMotoShopInventory.Services;

namespace KurtDhylanMotoShopInventory.Pages;

public class SearchPage : ContentPage
{
    readonly InventoryStore _store;
    readonly SearchBar _search = new() { Placeholder = "Search products and services..." };
    readonly VerticalStackLayout _results = new() { Spacing = 8 };

    public SearchPage(InventoryStore store)
    {
        _store = store;
        Title = "Search Inventory";
        BackgroundColor = Color.FromArgb("#0D0D0F");
        _search.TextChanged += async (_, _) => await Search();

        Content = new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = 16,
                Spacing = 12,
                Children = { _search, _results }
            }
        };
    }

    async Task Search()
    {
        _results.Clear();
        var q = _search.Text?.Trim().ToLowerInvariant() ?? "";
        if (string.IsNullOrWhiteSpace(q)) return;

        var products = (await _store.LoadProductsAsync()).Where(p =>
            p.Name.ToLowerInvariant().Contains(q) || p.Brand.ToLowerInvariant().Contains(q) || p.Model.ToLowerInvariant().Contains(q)).ToList();

        var services = (await _store.LoadServicesAsync()).Where(s => s.LaborName.ToLowerInvariant().Contains(q)).ToList();

        foreach (var p in products)
            _results.Add(Result($"PRODUCT • {p.Name}", $"{p.Brand} {p.Model} • ₱{p.Price:N2} • Stock {p.Stock}"));

        foreach (var s in services)
            _results.Add(Result($"SERVICE • {s.LaborName}", $"Labor • ₱{s.Price:N2}"));

        if (products.Count == 0 && services.Count == 0)
            _results.Add(new Label { Text = "No results.", TextColor = Color.FromArgb("#A9A9B0") });
    }

    static View Result(string title, string detail) => new Border
    {
        BackgroundColor = Color.FromArgb("#17171A"),
        Stroke = Color.FromArgb("#303036"),
        StrokeShape = new RoundRectangle { CornerRadius = 14 },
        Padding = 12,
        Content = new VerticalStackLayout
        {
            Children =
            {
                new Label { Text = title, TextColor = Colors.White, FontAttributes = FontAttributes.Bold, FontSize = 15 },
                new Label { Text = detail, TextColor = Color.FromArgb("#A9A9B0"), FontSize = 12 }
            }
        }
    };
}
