using KurtDhylanMotoShopInventory.Models;
using KurtDhylanMotoShopInventory.Services;

namespace KurtDhylanMotoShopInventory.Pages;

public class ServicesPage : ContentPage
{
    readonly InventoryStore _store;
    readonly VerticalStackLayout _list = new() { Spacing = 10 };
    readonly SearchBar _search = new() { Placeholder = "Search service / labor..." };
    List<ServiceItem> _services = new();

    public ServicesPage(InventoryStore store)
    {
        _store = store;
        Title = "Services";
        BackgroundColor = Color.FromArgb("#0D0D0F");

        var add = new Button
        {
            Text = "+ ADD SERVICE / LABOR",
            BackgroundColor = Color.FromArgb("#E50914"),
            TextColor = Colors.White,
            CornerRadius = 12,
            HeightRequest = 48
        };
        add.Clicked += async (_, _) => await AddService();

        _search.TextChanged += (_, _) => Render(_search.Text);

        Content = new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = 16,
                Spacing = 12,
                Children = { add, _search, _list }
            }
        };

        Appearing += async (_, _) =>
        {
            _services = await _store.LoadServicesAsync();
            Render(_search.Text);
        };
    }

    void Render(string? query)
    {
        _list.Clear();
        var q = query?.Trim().ToLowerInvariant() ?? "";
        var filtered = _services.Where(s => string.IsNullOrWhiteSpace(q) || s.LaborName.ToLowerInvariant().Contains(q)).ToList();

        foreach (var s in filtered)
        {
            var row = new Border
            {
                BackgroundColor = Color.FromArgb("#17171A"),
                Stroke = Color.FromArgb("#303036"),
                StrokeShape = new RoundRectangle { CornerRadius = 16 },
                Padding = 14,
                Content = new HorizontalStackLayout
                {
                    Spacing = 10,
                    Children =
                    {
                        new VerticalStackLayout
                        {
                            HorizontalOptions = LayoutOptions.StartAndExpand,
                            Children =
                            {
                                new Label { Text = s.LaborName, TextColor = Colors.White, FontSize = 16, FontAttributes = FontAttributes.Bold },
                                new Label { Text = $"Labor / Service • ₱{s.Price:N2}", TextColor = Color.FromArgb("#A9A9B0"), FontSize = 12 }
                            }
                        },
                        new Button { Text = "⋮", BackgroundColor = Colors.Transparent, TextColor = Colors.White }
                    }
                }
            };
            var menu = (Button)((HorizontalStackLayout)row.Content).Children[1];
            menu.Clicked += async (_, _) =>
            {
                var choice = await DisplayActionSheet(s.LaborName, "Cancel", null, "Edit", "Delete");
                if (choice == "Edit") await AddService(s);
                else if (choice == "Delete")
                {
                    _services.Remove(s);
                    await _store.SaveServicesAsync(_services);
                    Render(_search.Text);
                }
            };
            _list.Add(row);
        }
        if (filtered.Count == 0)
            _list.Add(new Label { Text = "No services found.", TextColor = Color.FromArgb("#A9A9B0"), HorizontalTextAlignment = TextAlignment.Center });
    }

    async Task AddService(ServiceItem? existing = null)
    {
        var name = await DisplayPromptAsync(existing == null ? "Add Service" : "Edit Service", "Labor / service name:", initialValue: existing?.LaborName ?? "");
        if (string.IsNullOrWhiteSpace(name)) return;

        var priceText = await DisplayPromptAsync("Service", "Price (₱):", initialValue: existing?.Price.ToString("0.00") ?? "");
        if (!decimal.TryParse(priceText, out var price) || price < 0)
        {
            await DisplayAlert("Invalid price", "Please enter a valid number.", "OK");
            return;
        }

        if (existing == null) _services.Add(new ServiceItem { LaborName = name, Price = price });
        else { existing.LaborName = name; existing.Price = price; }

        await _store.SaveServicesAsync(_services);
        Render(_search.Text);
    }
}
