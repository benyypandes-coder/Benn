using System.Text.Json;
using KurtDhylanMotoShopInventory.Models;

namespace KurtDhylanMotoShopInventory.Services;

public class InventoryStore
{
    private readonly string _productsFile = Path.Combine(FileSystem.AppDataDirectory, "products.json");
    private readonly string _servicesFile = Path.Combine(FileSystem.AppDataDirectory, "services.json");

    private readonly JsonSerializerOptions _json = new() { WriteIndented = true };

    public async Task<List<Product>> LoadProductsAsync()
    {
        if (!File.Exists(_productsFile))
            return new List<Product>();
        try
        {
            var json = await File.ReadAllTextAsync(_productsFile);
            return JsonSerializer.Deserialize<List<Product>>(json, _json) ?? new();
        }
        catch { return new(); }
    }

    public async Task SaveProductsAsync(List<Product> products) =>
        await File.WriteAllTextAsync(_productsFile, JsonSerializer.Serialize(products, _json));

    public async Task<List<ServiceItem>> LoadServicesAsync()
    {
        if (!File.Exists(_servicesFile))
            return new List<ServiceItem>();
        try
        {
            var json = await File.ReadAllTextAsync(_servicesFile);
            return JsonSerializer.Deserialize<List<ServiceItem>>(json, _json) ?? new();
        }
        catch { return new(); }
    }

    public async Task SaveServicesAsync(List<ServiceItem> services) =>
        await File.WriteAllTextAsync(_servicesFile, JsonSerializer.Serialize(services, _json));
}
